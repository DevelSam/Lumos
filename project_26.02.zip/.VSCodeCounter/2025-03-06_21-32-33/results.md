# Summary

Date : 2025-03-06 21:32:33

Directory c:\\Users\\MIXPC\\Desktop\\Kino\\kino

Total : 63 files,  7335 codes, 81 comments, 231 blanks, all 7647 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 3 | 4,980 | 0 | 3 | 4,983 |
| CSS | 17 | 1,271 | 48 | 88 | 1,407 |
| JavaScript JSX | 31 | 1,012 | 32 | 129 | 1,173 |
| JavaScript | 2 | 42 | 1 | 4 | 47 |
| HTML | 1 | 13 | 0 | 1 | 14 |
| XML | 8 | 12 | 0 | 2 | 14 |
| Markdown | 1 | 5 | 0 | 4 | 9 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 63 | 7,335 | 81 | 231 | 7,647 |
| . (Files) | 6 | 4,994 | 1 | 11 | 5,006 |
| public | 1 | 1 | 0 | 0 | 1 |
| src | 56 | 2,340 | 80 | 220 | 2,640 |
| src (Files) | 5 | 200 | 3 | 20 | 223 |
| src\\api | 12 | 284 | 7 | 26 | 317 |
| src\\assets | 7 | 11 | 0 | 2 | 13 |
| src\\components | 25 | 1,360 | 18 | 125 | 1,503 |
| src\\components\\Footer | 2 | 100 | 0 | 4 | 104 |
| src\\components\\Header | 2 | 109 | 0 | 8 | 117 |
| src\\components\\HeroSection | 2 | 175 | 1 | 23 | 199 |
| src\\components\\Hooks | 1 | 21 | 1 | 4 | 26 |
| src\\components\\KinoSlider | 2 | 150 | 15 | 16 | 181 |
| src\\components\\MovieActor | 2 | 64 | 0 | 9 | 73 |
| src\\components\\MovieHero | 2 | 174 | 0 | 11 | 185 |
| src\\components\\MovieInfo | 2 | 104 | 0 | 6 | 110 |
| src\\components\\MovieSimular | 2 | 129 | 0 | 11 | 140 |
| src\\components\\NewRelease | 2 | 141 | 1 | 20 | 162 |
| src\\components\\PlayerModal | 2 | 59 | 0 | 5 | 64 |
| src\\components\\Preloader | 2 | 19 | 0 | 2 | 21 |
| src\\components\\RandomFilm | 2 | 115 | 0 | 6 | 121 |
| src\\pages | 7 | 485 | 52 | 47 | 584 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)