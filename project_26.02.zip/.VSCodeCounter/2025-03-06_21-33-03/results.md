# Summary

Date : 2025-03-06 21:33:03

Directory c:\\Users\\MIXPC\\Desktop\\Kino\\kino\\src

Total : 56 files,  2340 codes, 80 comments, 220 blanks, all 2640 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| CSS | 17 | 1,271 | 48 | 88 | 1,407 |
| JavaScript JSX | 31 | 1,012 | 32 | 129 | 1,173 |
| JSON | 1 | 46 | 0 | 1 | 47 |
| XML | 7 | 11 | 0 | 2 | 13 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 56 | 2,340 | 80 | 220 | 2,640 |
| . (Files) | 5 | 200 | 3 | 20 | 223 |
| api | 12 | 284 | 7 | 26 | 317 |
| assets | 7 | 11 | 0 | 2 | 13 |
| components | 25 | 1,360 | 18 | 125 | 1,503 |
| components\\Footer | 2 | 100 | 0 | 4 | 104 |
| components\\Header | 2 | 109 | 0 | 8 | 117 |
| components\\HeroSection | 2 | 175 | 1 | 23 | 199 |
| components\\Hooks | 1 | 21 | 1 | 4 | 26 |
| components\\KinoSlider | 2 | 150 | 15 | 16 | 181 |
| components\\MovieActor | 2 | 64 | 0 | 9 | 73 |
| components\\MovieHero | 2 | 174 | 0 | 11 | 185 |
| components\\MovieInfo | 2 | 104 | 0 | 6 | 110 |
| components\\MovieSimular | 2 | 129 | 0 | 11 | 140 |
| components\\NewRelease | 2 | 141 | 1 | 20 | 162 |
| components\\PlayerModal | 2 | 59 | 0 | 5 | 64 |
| components\\Preloader | 2 | 19 | 0 | 2 | 21 |
| components\\RandomFilm | 2 | 115 | 0 | 6 | 121 |
| pages | 7 | 485 | 52 | 47 | 584 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)