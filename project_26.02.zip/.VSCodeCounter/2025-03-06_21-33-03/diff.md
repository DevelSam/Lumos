# Diff Summary

Date : 2025-03-06 21:33:03

Directory c:\\Users\\MIXPC\\Desktop\\Kino\\kino\\src

Total : 7 files,  -4995 codes, -1 comments, -11 blanks, all -5007 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| XML | 1 | -1 | 0 | 0 | -1 |
| Markdown | 1 | -5 | 0 | -4 | -9 |
| HTML | 1 | -13 | 0 | -1 | -14 |
| JavaScript | 2 | -42 | -1 | -4 | -47 |
| JSON | 2 | -4,934 | 0 | -2 | -4,936 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 7 | -4,995 | -1 | -11 | -5,007 |
| .. | 7 | -4,995 | -1 | -11 | -5,007 |
| .. (Files) | 6 | -4,994 | -1 | -11 | -5,006 |
| ..\\public | 1 | -1 | 0 | 0 | -1 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)