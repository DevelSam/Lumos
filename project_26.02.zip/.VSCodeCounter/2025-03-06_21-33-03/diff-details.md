# Diff Details

Date : 2025-03-06 21:33:03

Directory c:\\Users\\MIXPC\\Desktop\\Kino\\kino\\src

Total : 7 files,  -4995 codes, -1 comments, -11 blanks, all -5007 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [kino/README.md](/kino/README.md) | Markdown | -5 | 0 | -4 | -9 |
| [kino/eslint.config.js](/kino/eslint.config.js) | JavaScript | -37 | 0 | -2 | -39 |
| [kino/index.html](/kino/index.html) | HTML | -13 | 0 | -1 | -14 |
| [kino/package-lock.json](/kino/package-lock.json) | JSON | -4,903 | 0 | -1 | -4,904 |
| [kino/package.json](/kino/package.json) | JSON | -31 | 0 | -1 | -32 |
| [kino/public/vite.svg](/kino/public/vite.svg) | XML | -1 | 0 | 0 | -1 |
| [kino/vite.config.js](/kino/vite.config.js) | JavaScript | -5 | -1 | -2 | -8 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details