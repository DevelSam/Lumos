import './HeroSection.css'
import title_one from '../../assets/960x540.webp'
import title_two from '../../assets/TenLet-title.webp'
import title_three from '../../assets/ThreeSlideTitle.webp'
import title_four from '../../assets/FourSlideTitle.webp'
import 'swiper/css';
import 'swiper/css/bundle'
import background_one from '../../assets/2016x1134.webp'
import background_two from '../../assets/TenLet.webp'
import background_three from '../../assets/ThreeSlideBack.webp'
import background_four from '../../assets/FourSlideBackground.webp'
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Navigation, Pagination } from 'swiper/modules';
export default function HeroSection(){
    return(
    <section className="hero">
         <Swiper
         modules={[Navigation, Pagination, Autoplay]}
      spaceBetween={0}
      slidesPerView={1}
      speed={800}
    //   navigation
        autoplay = {{delay:3000}}
        loop = {true}
    >
      <SwiperSlide><div className="hero-bg"><img src={background_one} alt="" /></div>
        <div className="container container-hero">
            <div className="content-hero">
                <div className="hero-title__block">
                    <h1 className="hero-title"><img src={title_one} alt="" /></h1>
                    <p className="hero-description">Куда пропала Щука, исполняющая желания? Сказочные приключения на выставке чудес</p>
                </div>
                <div className="hero-controls">
                    <button className="hero-watch__button button">
                    <svg className='play-icon' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                    <path  d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80L0 432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"/>
                    </svg>
                        
                        Смотреть фильм</button>
                    <button className="hero-watch__button-description button">О фильме</button>
                </div>
            </div>
        </div>
        
        </SwiperSlide>
      <SwiperSlide><div className="hero-bg"><img src={background_two } alt="" /></div>
        <div className="container container-hero">
            <div className="content-hero">
                <div className="hero-title__block">
                    <h1 className="hero-title"><img src={title_two} alt="" /></h1>
                    <p className="hero-description">Судьба Вселенной — в руках обыкновенного школьника. Один из главных российских фильмов последних лет</p>
                </div>
                <div className="hero-controls">
                    <button className="hero-watch__button button">
                    <svg className='play-icon' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                    <path  d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80L0 432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"/>
                    </svg>
                        
                        Смотреть фильм</button>
                    <button className="hero-watch__button-description button">О фильме</button>
                </div>
            </div>
        </div></SwiperSlide>
      <SwiperSlide>
      <div className="hero-bg"><img src={background_three } alt="" /></div>
        <div className="container container-hero">
            <div className="content-hero">
                <div className="hero-title__block">
                    <h1 className="hero-title"><img src={title_three} alt="" /></h1>
                    <p className="hero-description">Сын русского олигарха находит родную душу в нью-йоркской танцовщице. У Юры Борисова — номинация на «Оскар»!

</p>
                </div>
                <div className="hero-controls">
                    <button className="hero-watch__button button">
                    <svg className='play-icon' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                    <path  d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80L0 432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"/>
                    </svg>
                        
                        Смотреть фильм</button>
                    <button className="hero-watch__button-description button">О фильме</button>
                </div>
            </div>
        </div>
      </SwiperSlide>
      <SwiperSlide>
      <div className="hero-bg"><img src={background_four } alt="" /></div>
        <div className="container container-hero">
            <div className="content-hero">
                <div className="hero-title__block">
                    <h1 className="hero-title"><img src={title_four} alt="" /></h1>
                    <p className="hero-description">Сын русского олигарха находит родную душу в нью-йоркской танцовщице. У Юры Борисова — номинация на «Оскар»!

</p>
                </div>
                <div className="hero-controls">
                    <button className="hero-watch__button button">
                    <svg className='play-icon' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                    <path  d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80L0 432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"/>
                    </svg>
                        
                        Смотреть фильм</button>
                    <button className="hero-watch__button-description button">О фильме</button>
                </div>
            </div>
        </div>
      </SwiperSlide>
      
    </Swiper>
        
   </section>
    )
}