
import { Swiper, SwiperSlide } from "swiper/react"
// import { useState } from "react";
import { Link } from "react-router-dom";
import PropTypes from "prop-types";
import "swiper/css";
import "swiper/css/bundle";
import './KinoSlider.css'
 
import { Autoplay, Navigation, Pagination } from 'swiper/modules';
function KinoSlider({data, title }) {
    // const [isLastSlide, setIsLastSlide] = useState(false)
    // const [isStartSlide, setIsStartSlide] = useState(true)
    console.log(data)
    // function handleSlideChange(swiper){
    //     setIsLastSlide(swiper.isEnd);
    //     setIsStartSlide(swiper.isBeginning);
    // }
    function formatRationg(rating){
        return Number.isInteger(rating) ? rating.toFixed(1): rating.toFixed(1);
    }
    return(
        <section className='kino'>
        <div className='container kino-container'>
            <div className="kino-title__container">
            <h2 className='kino-title'>{title}</h2>
            <button className="kino-button">Смотреть все</button>
            </div>
            <Swiper
                className='kino-Slider'
                 modules={[Navigation, Pagination, Autoplay]}
                spaceBetween={30}
                slidesPerView={5}
                speed={800}
                // navigation= {{
                //     nextEl:'.kino-button-next',
                //     prevEl:'.kino-button-prev'
                // }}
                // onSlideChange={handleSlideChange}
                // autoplay={{ delay: 3000 }}
                
            >   
                {data.docs.map((movie) => (
                    <SwiperSlide key={movie.id} >
                        <Link to ={`/film/${movie.id}`}>
                        <div className="kino-content">
                            <div className="kino-image__block">
                            <img src={movie.poster.url} className="kino-image" alt="" />  
                            </div>
                            {movie.rating.imdb || movie.rating.kp ? (
                            <div className="kino-score">
                               
                                <div className="kino-score__container  ">
                                    <span className="kino-score__numbers "> { formatRationg(movie.rating.imdb || movie.rating.kp)}</span>
                                </div>
                                
                            </div>
                            ):null}    
                            <p className="kino-name">{movie.name}</p>
                        </div>
                        </Link>

                    </SwiperSlide>
                ))}
                
            </Swiper>
            
            {/* <div className={`${isLastSlide ? 'hidden' : ''} kino-button-next `}>&#8250;</div>
            <div className={`${isStartSlide ? 'hidden' : ''} kino-button-prev `}>&#8249;</div> */}
            
        </div>
    </section>
    )
}
KinoSlider.propTypes = {
    data: PropTypes.any,
    title : PropTypes.string,
}
export default  KinoSlider