import HeroSection from '../components/HeroSection/HeroSection'
import Header from '../components/Header/Header'
import KinoSlider from '../components/KinoSlider/KinoSlider'
import RandomFilm from '../components/RandomFilm/RandomFilm'
import { FetchTopFilms } from '../api/FetchTopFilms'
import { FetchRandomFilm } from '../api/FetchRandomFilm'
import { FetchTopSerials } from '../api/FetchTopSerials'
import { FetchWaitFilms } from '../api/FetchWaitFilms'
import { FetchAnime } from '../api/FetchAnime'
import { FetchRandomSerials } from '../api/FetchRandomSerials'
import Footer from '../components/Footer/Footer'
import {useQuery} from 'react-query'

export default function MainPage(){
    const {data:topFilmsData, isLoading:topFilmsLoading} = useQuery('topFilms', FetchTopFilms)
    const {data:randomFilmsData, isLoading:randomFilmsLoading} = useQuery('randomFilms', FetchRandomFilm)
    const {data:topSerialsData, isLoading:topSerialsLoading} = useQuery('topSerials', FetchTopSerials)
    const {data:waitFilmsData, isLoading:waitFilmsLoading} = useQuery('waitFilms', FetchWaitFilms)
    const {data:animeData, isLoading:animeLoading} = useQuery('anime', FetchAnime)
    const {data:randomSerialsData, isLoading:randomSerialsLoading} = useQuery('randomSerials', FetchRandomSerials)
     return (
        <>
        <Header/>
          <main>
            
            <HeroSection />
            { topFilmsLoading || randomFilmsLoading || topSerialsLoading || waitFilmsLoading || animeLoading || randomSerialsLoading ? (
              <p>Loading...</p>
            ) : (
              <>
                {/* {console.log(randomData)} */}
                <KinoSlider data={topFilmsData} title={'Лучшие фильмы'} />
                <KinoSlider data={animeData} title={'Аниме'} />
                <RandomFilm data={randomFilmsData} title={'Рандомный фильмов с оценкой 8+'} />
                <KinoSlider data={topSerialsData} title={'Лучшие Сериалы'} />
                <KinoSlider data={waitFilmsData} title={'Ожидаемые больше всех'} />
                <RandomFilm data={randomSerialsData} title={'Рандомный сериал с оценкой 8+'} />
              </>
            )}
          </main>
          <Footer/>
        </>
      )
}