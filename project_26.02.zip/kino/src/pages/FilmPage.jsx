import { useQuery } from "react-query"
import { useParams } from "react-router-dom"
import { FetchFilmId } from "../api/FetchFilmId"
import './FilmPage.css'


export default function FilmPage(){
    const params = useParams()
    const id = parseInt(params.id)
    const {data:filmsdata, isLoading:filmLoading } = useQuery(['filmdata', id], () =>  FetchFilmId(id))
    return(
        <section className="film">
            <div className="container container-film">
                
                {filmLoading ? (
                    <p>Страница загружаеться</p>
                ): (
                    <div className="content">
                        <img src={filmsdata.poster.url} alt="" className="film-poster" />
                        <p className="film-title">{filmsdata.name}</p>
                        <p className="film-slogan">{filmsdata.slogan}</p>
                    </div>
                )}
            </div>
        </section>
    )
}