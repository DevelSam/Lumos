
export const FetchTopSerials = async () => {
    const options = {
        method: 'GET',
        headers: {
          accept: 'application/json',
          'X-API-KEY': 'KAK5971-W7T4JWN-HJMJNXD-EMYD3KG'
        }
      };
      try{
        
        const response =  await fetch('https://api.kinopoisk.dev/v1.4/movie?page=1&limit=12&selectFields=&notNullFields=top250&sortField=top250&sortType=1&lists=series-top250', options)
     
        if(!response.ok) {
            throw new Error('Запрос не сработал!')
        }
        
        return await response.json()
    }
      catch(err){
        console.error('Ошибка запроса!', err)
        throw err
      }
}
